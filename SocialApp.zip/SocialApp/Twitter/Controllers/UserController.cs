using System.Diagnostics;
using BLL;
using BOL;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Twitter.Models;

namespace Twitter.Controllers;

public class UserController : Controller
{
    private readonly ILogger<UserController> _logger;

    public UserController(ILogger<UserController> logger)
    {
        _logger = logger;
    }
    [HttpGet]
    public IActionResult Login()
    {
        return View();
    }

    [HttpPost]

    public IActionResult Login(string email, string pass)
    {
        UserManager u_mgr = new UserManager();
        Console.WriteLine("hiiii...");
        Console.WriteLine(email, pass);
        if(u_mgr.checkUser(email, pass))
        {
            return this.RedirectToAction("welcome");
        }
        else
        {
            this.ViewData["msg"] = "Invalid Email or Password !";
            return View();
        }

    }
    public IActionResult Welcome()
    {
        return View();
    }
    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }


}
