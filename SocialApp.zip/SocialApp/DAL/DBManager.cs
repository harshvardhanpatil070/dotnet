namespace DAL;
using BOL;
using MySql.Data.MySqlClient;
public class DBManager{
    private static string conString="server=192.168.10.150;port=3306;user=dac5;password=welcome;database=dac5";
    private static MySqlConnection ?con=null;

    public static List<User> getAllUser(){
        string query = "SELECT * FROM twitteruser";
        con= new MySqlConnection();
        con.ConnectionString=conString;
        List<User> uwu=new List<User>();
        MySqlCommand cmd=new MySqlCommand(query,con);
        try
        {
            con.Open();
            MySqlDataReader rea=cmd.ExecuteReader();
            while(rea.Read()){
                string email=rea["email"].ToString();
                string username=rea["username"].ToString();
                string password=rea["password"].ToString();
                 uwu.Add(new User(email,username,password));
            }
        
        }
        catch (Exception e)
        {
          Console.WriteLine("Error: "+e.Message);
        }
        finally{
            con.Close();
        }


        return uwu;
    }
    public static Boolean validate(string email, string pass){
        List<User> u_list = getAllUser();
        foreach(User u in u_list){
            if(u.email==email && u.password==pass)
                return true;
        }
        return false;
    }

}
