namespace BLL;

using DAL;
using BOL;
public class UserManager{
    public List<UserManager> getAll(){
        
    }
}