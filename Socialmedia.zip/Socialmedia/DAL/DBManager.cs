namespace DAL;
using BOL;
using MySql.Data.MySqlClient;
public class DBManager{
    public static string constring="server=192.168.10.150;port=3306;user=dac5;password=welcome;database=dac5";
    public static MySqlConnection ?conn=null;
    public static List<User> GetAllUser(){
        List<User> use=new List<User>();
        conn = new MySqlConnection();
        conn.ConnectionString=constring;
        string query="select * from login";
        MySqlCommand cmd= new MySqlCommand(query,conn);
        try{
            conn.Open();
            MySqlDataReader rd= cmd.ExecuteReader();
            

        }

    }
}