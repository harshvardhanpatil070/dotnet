namespace NotifyUser;

public delegate void NotificationOperation(String to,String content);