namespace txtop;
using bankrecord;

public delegate void TaxOperation(int amount);
