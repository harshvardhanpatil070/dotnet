﻿namespace OrderProcessing;
public interface IOrderDetails
{
    void ShowDetails();
    void ShowOrderDetails();
}
