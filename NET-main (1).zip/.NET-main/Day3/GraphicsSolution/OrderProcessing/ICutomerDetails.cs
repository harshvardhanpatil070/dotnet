namespace OrderProcessing;
public interface ICustomerDetails{
    void ShowDetails();
    void ShowCustomerDetails();
    void ChangeProfile();
}