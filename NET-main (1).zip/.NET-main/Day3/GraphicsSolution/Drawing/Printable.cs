namespace Drawing;
//interfaces are immutable

public interface IPrintable{
    //will only define characteristics
    void Print();

}