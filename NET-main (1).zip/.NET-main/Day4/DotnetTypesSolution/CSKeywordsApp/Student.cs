namespace Training;

public partial class Student{

public int PRN {get;set;}
public string FullName{get;set;}
}