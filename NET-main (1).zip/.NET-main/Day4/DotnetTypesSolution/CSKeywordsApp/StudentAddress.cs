namespace Training;


public partial class Student{
    public string Email{get;set;}
    public string Location{get;set;}
}