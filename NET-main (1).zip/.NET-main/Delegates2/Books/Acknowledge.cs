namespace acknowledge;

public class Acknowledge{

    public void msg()
    {
        Console.WriteLine("No of copies not availble right now!");
    }
}