namespace ackDeligate;

public delegate void AckDeligates();