﻿namespace Billing;
public class Class1
{

}
